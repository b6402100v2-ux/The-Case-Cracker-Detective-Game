# The Case Crackers

A browser-based multiplayer detective game for classroom use. Students work in squads of 4 to read diary-style evidence panels, answer comprehension questions, and vote on the correct verdict together.

---

## Project Structure

```
case-crackers/
├── artifacts/
│   ├── detective-game/    # React + Vite frontend
│   └── api-server/        # Express + TypeScript backend (in-memory, no database)
├── package.json
├── pnpm-workspace.yaml
└── tsconfig.base.json
```

---

## Prerequisites

- [Node.js](https://nodejs.org/) v18 or higher
- [pnpm](https://pnpm.io/) v9 or higher

Install pnpm if you don't have it:
```bash
npm install -g pnpm
```

---

## Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/case-crackers.git
cd case-crackers
```

### 2. Install dependencies

```bash
pnpm install
```

### 3. Run both servers in development mode

```bash
pnpm dev
```

This starts:
- **API server** on `http://localhost:8080`
- **Game frontend** on `http://localhost:5173`

Open `http://localhost:5173` in your browser.

---

## Running each server separately

**API server only:**
```bash
pnpm --filter @workspace/api-server run dev
```

**Frontend only:**
```bash
pnpm --filter @workspace/detective-game run dev
```

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `5173` | Port for the frontend dev server |
| `BASE_PATH` | `/` | Base URL path for the frontend |

The API server always runs on port **8080**.

---

## Game Flow

1. **Title Screen** — Rules overview and badge tiers
2. **Case Select** — Choose a case (Case 101 is live; 102 & 103 coming soon)
3. **Join** — Enter detective name, squad code, icon, and panel number (1–4)
4. **Individual Panel** — Read your diary entry, answer 5 multiple-choice questions
   - Wrong answer shows a hint and restarts from Q1
   - Badge awarded only if all 5 are answered with zero mistakes
5. **Collaboration** — All 4 detectives assemble, share scores, discuss evidence (10-min timer)
6. **Verdict** — Vote on the correct answer (2 rounds; must be unanimous)
7. **Ending** — Final score, badge, and play-again option
8. **Teacher Leaderboard** — Live dashboard auto-refreshing every 5 seconds

---

## Cases

| Case | Title | Skill | Status |
|------|-------|-------|--------|
| 101 | The Silent Notification | Main Idea | ✅ Playable |
| 102 | Last Chat: Who Killed Alex? | Skimming & Scanning | 🔒 Coming Soon |
| 103 | Judas Manor: The Diamond Thief | Making Inferences | 🔒 Coming Soon |

---

## Tech Stack

- **Frontend:** React 19, Vite 7, Tailwind CSS 4, Framer Motion
- **Backend:** Express, TypeScript, in-memory state (no database required)
- **Fonts:** Bangers (titles), Courier New (evidence text)

---

## Building for Production

```bash
pnpm build
```

Frontend output: `artifacts/detective-game/dist/public`  
API server output: `artifacts/api-server/dist`
